
/* 
 * File:   log.h
 * Author: Manuel
 *
 * Created on 17 de fevereiro de 2023, 14:04
 */

#ifndef LOG_H
#define LOG_H

#include <string.h>
#include <time.h>


void logMsg(char *msg);

#endif /* LOG_H */

